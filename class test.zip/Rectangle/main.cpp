#include <iostream>
#include "rectangle.h"

using namespace std;

int main() {
    //initialise class
    rectangle test;

    //testing. first one uses default values specified in header file.
    cout << test.area()<< endl;
    cout << test.perimeter()<< endl;

    test.setValues(2,5);

    cout << test.area()<< endl;

    cout << test.perimeter()<< endl;


    return 0;
}
