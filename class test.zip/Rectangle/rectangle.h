//
// Created by labuser on 4/5/2024.
//

#ifndef UNTITLED1_RECTANGLE_H
#define UNTITLED1_RECTANGLE_H


class rectangle {
private:
    float length;
    float width;
public:
    rectangle();

    //this is where default parameters are entered.
    void setValues(float, float);
    //just takes class parameters as is
    float perimeter();
    float area();
};

#endif //UNTITLED1_RECTANGLE_H
