//
// Created by labuser on 4/5/2024.
//
#include <iostream>
#include "rectangle.h"

rectangle::rectangle() {
    length=1;
    width=1;
}

void rectangle::setValues(float l, float w)
{
    length=l;
    width=w;
}

float rectangle::perimeter()
{
    if(length<20.0 && length>0.0 && width<20.0 && width>0.0)
    {
        return (2*(length+width));
    }
    else
    {
        return -1;
    }

}

float rectangle::area() {

    if(length<20.0 && length>0.0 && width<20.0 && width>0.0)
    {
        return (length*width);
    }
    else
    {
        return -1;
    }

}
