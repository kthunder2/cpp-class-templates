//
// Created by labuser on 4/5/2024.
//
#include <iostream>
#include "Time.h"

using std::cout;

Time ::Time() {
    hour=0;
    minute=0;
    second=0;
}

void Time::setTime(int h, int m, int s) {
    hour=h;
    minute=m;
    second=s;

}

void Time::getTime() {
    cout << ((hour < 10)?"0":"") << hour << ":";
    cout << ((minute < 10)?"0":"") << minute << ":";
    cout << ((second < 10)?"0":"") << second << ":";
}
