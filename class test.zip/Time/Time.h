//
// Created by labuser on 4/5/2024.
//

#ifndef UNTITLED_TIME_H
#define UNTITLED_TIME_H


class Time {
private:
    int hour;
    int minute;
    int second;

public:
    Time();
    void setTime(int,int,int);
    void getTime(void);
};


#endif //UNTITLED_TIME_H
