#include <iostream>
#include "Time.h"

using namespace std;

int main() {
    Time mytime1;
    mytime1.setTime(13, 11, 10);

    mytime1.getTime();
    Time *mytime2 = new Time();
    mytime2->setTime(5, 13, 45);
    mytime2->getTime();
    delete mytime2;

    return 0;
}
